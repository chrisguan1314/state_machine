#pragma once

#include <memory>
#include <string>
#include <thread>
#include <mutex>
#include <chrono>
#include <queue>
#include <condition_variable>
#include <type_traits>
#include <filesystem>

#include "public_param\public_param.h"
#include "function_param\function_param.h"
#include "algorithm_param\algorithm_param.h"

using namespace std::chrono;

class ParamManager
{
public:
    struct Request
    {};
private:
    std::filesystem::path param_path_;
    std::shared_ptr<PublicParam> public_param_{nullptr};
    std::shared_ptr<FunctionParam> function_param_{nullptr};
    std::shared_ptr<AlgorithmParam> algorithm_param_{nullptr};
    std::queue<Request> queue_;
    std::mutex mtx_;
    std::condition_variable cv_;
    std::unique_ptr<std::thread> rcv_trd_{nullptr};
    std::unique_ptr<std::thread> pub_trd_{nullptr};
public:
    template <typename T, typename = typename std::enable_if_t<std::is_same_v<std::decay_t<T>, std::filesystem::path>>>
    ParamManager(T && path) : 
    param_path_(std::forward<T>(path)),
    public_param_(std::make_shared<PublicParam>(param_path_/std::filesystem::path("public"))),
    function_param_(std::make_shared<FunctionParam>(param_path_/std::filesystem::path("function"))),
    algorithm_param_(std::make_shared<AlgorithmParam>(param_path_/std::filesystem::path("algorithm")))
    {
        std::cout << "param path : " << param_path_ << std::endl;
    }
    ~ParamManager()
    {
        if (rcv_trd_ && rcv_trd_->joinable())
        {
            rcv_trd_->join();
        }
        if (pub_trd_ && pub_trd_->joinable())
        {
            pub_trd_->join();
        }
    }
public: 
    std::shared_ptr<PublicParam> GetPublicParam() const noexcept
    {
        return public_param_;
    }
    std::shared_ptr<FunctionParam> GetFunctionParam() const noexcept
    {
        return function_param_;
    }
    std::shared_ptr<AlgorithmParam> GetAlgorithmParam() const noexcept
    {
        return algorithm_param_;
    }
    void SetUp()
    {
        InitReadersAndWriters();
        if (rcv_trd_ = std::make_unique<std::thread>(&ParamManager::HandleReceiver, this))
        {
            std::cout << "Succeed to Create Receiver Thread of ParamManager!" << std::endl;
        }
        else
        {
            std::cout << "Failed to Create Receiver Thread of ParamManager!" << std::endl;
        }

        if (pub_trd_ = std::make_unique<std::thread>(&ParamManager::HandlePublisher, this))
        {
            std::cout << "Succeed to Create Publisher Thread of ParamManager!" << std::endl;
        }
        else
        {
            std::cout << "Failed to Create Publisher Thread of ParamManager!" << std::endl;
        }
    }
    void InitReadersAndWriters()
    {

    }
    void ModifyParam(Request rqst)
    {
        ModifyParamInBuffer();
        ModifyParamInFile();
    }
    void ModifyParamInBuffer()
    {

    }
    void ModifyParamInFile()
    {
        
    }
    void HandleReceiver()
    {
        while (true)
        {
            std::unique_lock<std::mutex> lck(mtx_);
            cv_.wait(lck, [this]{ 
                std::cout << "111" << std::endl;
                return !queue_.empty(); 
            });
            auto rqst = queue_.front();
            queue_.pop();
            lck.unlock();
            ModifyParam(rqst);
        }
    }
    void HandlePublisher()
    {
        while (true)
        {
            auto start = steady_clock::now();
            std::cout << "111" << std::endl;
            auto duration_count = duration_cast<milliseconds>(steady_clock::now() - start).count();
            if (duration_count < 50)
            {
                std::this_thread::sleep_for(milliseconds(50 - duration_count));
            }
        }
    }
    void Receiver()
    {
        Request rqst;
        {
            std::lock_guard<std::mutex> lck(mtx_);
            queue_.push(std::move(rqst));
        }
        cv_.notify_one();
    }
};