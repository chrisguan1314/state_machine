#pragma once

#include "apa_switch_param.h"
#include "apa_value_param.h"

#include <string>
#include <filesystem>

struct ApaParam
{
public:
    std::filesystem::path apa_param_path_;
    ApaSwitchParam switch_param_;
    ApaValueParam value_param_;
public:
    template <typename T, typename = typename std::enable_if_t<std::is_convertible_v<std::decay_t<T>, std::filesystem::path>>>
    ApaParam(T && path) : 
    apa_param_path_(std::forward<T>(path)),
    switch_param_(ApaSwitchParam(apa_param_path_/std::filesystem::path("switch_param.json"))),
    value_param_(ApaValueParam(apa_param_path_/std::filesystem::path("value_param.json")))
    {
        std::cout << "apa param path : " << apa_param_path_ << std::endl;
    }
};