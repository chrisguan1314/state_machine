#pragma once

#include <string>
#include <atomic>
#include <iostream>
#include <filesystem>
#include <type_traits>

struct ApaSwitchParam
{
private:
    std::filesystem::path apa_switch_param_path_;
public:
    std::atomic<bool> front_camera_switch_{true};
    std::atomic<bool> rear_camera_switch_{true};
    std::atomic<bool> left_camera_switch_{true};
    std::atomic<bool> right_camera_switch_{true};
public:
    template <typename T, typename = typename std::enable_if_t<std::is_convertible_v<std::decay_t<T>, std::filesystem::path>>>
    ApaSwitchParam(T && path) : apa_switch_param_path_(std::forward<T>(path))
    {
        std::cout << "apa switch param path : " << apa_switch_param_path_ << std::endl;
    }
};