#pragma once

#include <memory>
#include <string>
#include <filesystem>

#include "pilot\pilot_param.h"
#include "parking\parking_param.h"
#include "as\as_param.h"

struct FunctionParam
{
private: 
    std::filesystem::path function_param_path_;
public:
    PilotParam pilot_param_;
    ParkingParam parking_param_;
    AsParam as_param_;
public: 
    template <typename T, typename = typename std::enable_if_t<std::is_convertible_v<std::decay_t<T>,  std::filesystem::path>>>
    FunctionParam(T && path) : 
    function_param_path_(path),
    pilot_param_(PilotParam(path/std::filesystem::path("pilot"))),
    parking_param_(ParkingParam(path/std::filesystem::path("parking"))),
    as_param_(AsParam(path/std::filesystem::path("as")))
    {
       std::cout << "function param path : " << function_param_path_ << std::endl; 
    }
};